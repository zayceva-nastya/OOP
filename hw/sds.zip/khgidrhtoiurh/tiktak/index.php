<?php
include 'autoload.php';

$tic = new Tictac(3);

// $tic->initMap(5);
print_r($tic->map);
$tic->putCross(2,2);
print_r($tic->map);
$tic->putNull(1,1);
$tic->putNull(2,2);
print_r($tic->map);