<?php

class OL extends Li
{
    protected $type = "1";
    protected $avalibleType = ["1", "I", "i"];
    protected $tagName = "ol";
}
