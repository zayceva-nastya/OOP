<?php


class UL extends Li
{
    protected $type = "circle";
    protected $avalibleType = ["square", "circle", "disk"];
    protected $tagName = "ul";
}
