<?php

class Area extends Tictac
{
    public function show()
    {
    }
}